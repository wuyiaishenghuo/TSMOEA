This source code is for the paper A Two-Stage Evolutionary Algorithm for Many-Objective Optimization of EMO2019(10th International Conference on Evolutionary Multi-Criterion Optimization).

The proposed algorithm TSMOEA is in the the subfloder "-Algorithms": choose "TSMOEA".

RUN:
1.main('-algorithm',@TSMOEA,'-problem',@DTLZ2,'-N',91,'-M',91000);
2.RUN main.m, then click the buttons in the GUI.
You can read the manual before you use it. 

If you have any questions, please send me an email to 986879902@qq.com.