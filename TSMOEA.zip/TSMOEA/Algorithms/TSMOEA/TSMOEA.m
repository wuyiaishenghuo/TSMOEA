function TSMOEA(Global)
% <algorithm> <H-N>
% A Two-Stage Evolutionary Algorithm for Many-Objective Optimization
% EMO 2019
% 

%--------------------------------------------------------------------------
% Copyright (c) 2016-2017 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB Platform
% for Evolutionary Multi-Objective Optimization [Educational Forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------

     %% Parameter setting
    delta = Global.ParameterSet(0.9);
    is_global = Global.ParameterSet(1);
%     part  = Global.ParameterSet(0.7);
    %% Generate the reference points and random population
    [Z,Global.N] = UniformPoint(Global.N,Global.M);
    Population   = Global.Initialization();
    Zmin         = min(Population(all(Population.cons<=0,2)).objs,[],1);
    %�ھӣ�neighbor set
    B = pdist2(Z,Z);
    [~,B] = sort(B,2);
    T = ceil(Global.N/10);
    B = B(:,1:T);
    
    % parameter setting
    flag=0; %for weight vectors adapation
    flag1=0; %for the reference point for calculating HV 
    %Generation=0 before 70% generations
    Generation=0; %��70%��ʼ����
    %calculate HV values per Gen generations
    Gen=2*Global.M; %ÿ��Gen��������һ��HV
    part1_flag=1; % for the first stage
    hypervolume=[];
    theta=5;
    %% Optimization
    while Global.NotTermination1(Population)
        if part1_flag
            MatingPool = TournamentSelection(2,Global.N,sum(max(0,Population.cons),2));
            Offspring  = Global.Variation(Population(MatingPool));
            Zmin       = min([Zmin;Offspring(all(Offspring.cons<=0,2)).objs],[],1);
%             Population = EnvironmentalSelection([Population,Offspring],Global.N,Z,Zmin) ;
            if isempty(hypervolume)
                Population = EnvironmentalSelection([Population,Offspring],Global.N,Z,Zmin) ; % ORIGINAL nsga-iii
            else
%                 Population = EnvironmentalSelection([Population,Offspring],Global.N,Z,Zmin) ;
                Population = EnvironmentalSelection3([Population,Offspring],Global.N,Z,Zmin,B) ; % a variant of NSGA-III
            end
            if Global.part1  %�Ѽ���70%,��ʼÿ��Gen������һ��HV
%                 Zmax = max(Population(all(Population.cons<=0,2)).objs,[],1);
%                 if max(Zmax)/min(Zmax)>1.2
%                     Gen=inf;
%                     continue; 
%                 end
                if flag1==0
                    RefPoint = max(Population.objs,[],1);
                    flag1=1;
                end
                if mod(Generation,Gen)==0
                    hypervolume = [hypervolume,hv(Population.objs,RefPoint)];
                end
                if length(hypervolume)>1 %2��ֵ���ϲ��ܱȽ�
                    k = (hypervolume(end)-hypervolume(end-1))/Gen;
                    if k<0.005*Global.M %k/Global.M<0.05  slope_hv
                        part1_flag=0;
                    end
                end
                Generation = Generation+1;
            end
        else
            if flag==0 %MOEA/DD�ĳ�ʼ���͸���Ȩ������
                  %MOEA/DD�ĳ�ʼ��
                  %initialization for MOEA/DD and weight vectors adapation 
                  Zmax=max(Population(all(Population.cons<=0,2)).objs,[],1);
                  W=Z.*repmat(Zmax-Zmin,size(Z,1),1);
                 [~,Region] = max(1-pdist2(Population.objs,W,'cosine'),[],2);
                 %����Ӧ���³ͷ�ϵ��theta
                 if is_global
                    theta=adaptive_theta(Population.objs,Zmax,theta);
                 end
                 %[~,Region] = max(1-pdist2(Population.objs,Z,'cosine'),[],2);
                  FrontNo    = NDSort(Population.objs,inf);
                  %����Ȩ������
                  %�������ķֲ������
                  Crowd     = hist(Region,1:size(Z,1));
                  %K��Ȩ���������������н� 
                  K=sum(Crowd>0);
                  rand_p=0;
                  if K/Global.N<0.9  %
                      %��Ҫ����(�����ӣ���ɾ��)
                      %��ӵ���������Ȩ������
%                       if K/Global.N<0.5
%                           rand_p=0;                  
%                       end
%                       need_add = find(Crowd>1);   %������ӵ�еĸ��峬��1,are crowded subregions
%                       Z = sortrows(Z);
                      % Distance between two consecutive reference points for the adaption
                      interval = Z(1,end) - Z(2,end);
                      is_twolayer=0;
                      if(interval~=(Z(end,1) - Z(end-1,1)))
                          interval=(Z(end,1) - Z(end-1,1))*2;
                          is_twolayer=1;
                      end
%                       ZK=Z(Crowd>0,:);
%                       Crowd=Crowd(Crowd>0);
                      %weight vectors adapation
                      Z=Adaptive_w5(Population.objs,Z,Global.N,interval,Crowd,Zmax,Zmin,is_twolayer,B);
                      [~,Region] = max(1-pdist2(Population.objs,Z,'cosine'),[],2);
                      Crowd     = hist(Region,1:size(Z,1));
                      %����B
                  else
                      Z=W;
                  end
                  B = pdist2(Z,Z);
                  [~,B] = sort(B,2);
                  B = B(:,1:T);
                  flag=1;   %ֻʹ��һ��                 
            end
            %%MOEA/DD
            for i = 1 : Global.N            
            % Choose the parents
            Ei = find(ismember(Region,B(i,:)));
            if rand < delta && length(Ei) >= 2
                P = Ei(TournamentSelection(2,2,sum(max(0,Population(Ei).cons),2)));
            else
                P = TournamentSelection(2,2,sum(max(0,Population.cons),2));
            end

            % Generate an offspring
            Offspring = Global.Variation(Population(P),1);
            [~,offRegion] = max(1-pdist2(Offspring.obj,Z,'cosine'));

            % Add the offspring to the population
            Population = [Population,Offspring];
            PopObj     = Population.objs;
            Region     = [Region;offRegion];
            %�ж��Ӵ��Ƿ��ھӸ���֧��
%             %����ȷ���Ӵ�����������������Bȷ���ھӸ��壬��T�������ڣ���ENLU�㷨����
%             NEi = find(ismember(Region,B(offRegion,:))); %��������
%             %���Ӵ������Ӽ�����
%             subpop=Population(NEi);
%             subpopobj=subpop.objs;
%             if length(NEi)>T-1
%                 subFrontNo = FrontNo(NEi(1:end-1));
%                 subFrontNo = UpdateFront(subpopobj,subFrontNo);  %����������ǵ�ǰ�����������������ô�죿
%                 FrontNo=[FrontNo,subFrontNo(end)];
%             else
%                 FrontNo    = UpdateFront(PopObj,FrontNo);
%             end
            FrontNo    = UpdateFront(PopObj,FrontNo);
            CV         = sum(max(0,Population.cons),2);
            
            % Update the ideal point
            Zmin = min(Zmin,Offspring.obj);

            % Delete a solution from the population
            if any(CV>0)
                [~,S] = sort(CV,'descend');
                S     = S(1:sum(CV>0));
                flag  = false;
                for j = 1 : length(S)
                    if sum(Region==Region(S(j))) > 1
                        flag = true;
                        x    = S(j);
                        break;
                    end
                end
                if ~flag
                    x = S(1);
                end
            elseif max(FrontNo) == 1
                x = LocateWorst(PopObj,Z,Region,FrontNo,Zmin,theta);
            else
                Fl = find(FrontNo==max(FrontNo));
                if length(Fl) == 1
%                     x = Fl;
                    if sum(Region==Region(Fl)) == 1 
                        x = LocateWorst(PopObj,Z,Region,FrontNo,Zmin,theta);
%                         x = Fl;
                    else
                        x = Fl;
%                         x = LocateWorst(PopObj,Z,Region,FrontNo,Zmin);
                    end
                else
                    SubRegion = unique(Region(Fl));
                    Crowd     = hist(Region(ismember(Region,SubRegion)),1:size(Z,1));
                    
                    Phi       = find(Crowd==max(Crowd));
                    PBI       = CalPBI(PopObj,Z,Region,Zmin,ismember(Region,Phi),theta);
                    PBISum    = zeros(1,size(Z,1));
                    for j = 1 : length(PBI)
                        PBISum(Region(j)) = PBISum(Region(j)) + PBI(j);
                    end
                    [~,Phi] = max(PBISum);
                    Phih    = find(Region==Phi);
                    if length(Phih) > 1
                        [~,x] = max(PBI(Phih));
                        x = Phih(x);
                    else
                        x = LocateWorst(PopObj,Z,Region,FrontNo,Zmin,theta);
                    end
                end
            end
            Population(x) = [];
            Region(x)     = [];
            if FrontNo(x)==max(FrontNo)
                FrontNo(x)=[];
            else
                FrontNo       = UpdateFront(Population.objs,FrontNo,x);
            end
            end
%             debug_Crowd = hist(Region,1:size(Z,1));
%             debug_index=find(debug_Crowd==0)
        end     
    end
end