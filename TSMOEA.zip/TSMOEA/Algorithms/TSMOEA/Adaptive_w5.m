function Z = Adaptive_w5(PopObj,Z,N,interval,Crowd,Zmax,Zmin,is_twolayer,B)
% Addition and deletion of reference points
    M = size(PopObj,2);
    B=B(:,1:1);
    del_index=[];
    %W = max(W,1e-6);
    %��1e-6��Ϊ0
    Z(Z==1e-6)=0;
%     for i=1:N
%         if Crowd(i)==0
%             if sum(Crowd(B(i,:)))==0  %BҪ��Ҫ���¶��壿
%                 del_index=[del_index,i];
%             end
%         end
%     end
    
    remained_index=setdiff([1:N],del_index);
    Crowd=Crowd(remained_index);
    Z=Z(remained_index,:);
    old_Crowd = Crowd;
    K = length(Crowd);
    old_Z = [];
    if is_twolayer
        H2=1/interval;
        num_2thlayer=nchoosek(H2+M-1,M-1);
        num_1thlayer=N-num_2thlayer;
        idx=find(remained_index<=num_1thlayer);
        idx=idx(end);
    end
    flag=1;
    while any(Crowd>=2) && ~isequal(old_Z,Z) 
        old_Z = Z;       
        flag=0;
        for i = find(Crowd>=1)
            p=[];
            %�Ƿ���Ҫ�����ж���H1�����ı�ԵȨ�������������м�����������Ǳ�Ե����������Χ��������
            if is_twolayer
                if all(Z(i,:)>(1/(2*M))) %���
                    p = repmat((Z(i,:)-1./(2*M))*2,M,1) - interval/M;
                    p(logical(eye(M))) = p(logical(eye(M))) + interval;  
                    p(any(p<0,2),:) = [];
                    p=p/2+1./(2*M);  
                else
                    p = repmat(Z(i,:),M,1) - interval/M;
                    p(logical(eye(M))) = p(logical(eye(M))) + interval;
                end 
            else
                p = repmat(Z(i,:),M,1) - interval/M;
                p(logical(eye(M))) = p(logical(eye(M))) + interval;
            end
            Z = [Z;p];
            Z(any(Z<0,2),:) = [];
        end
        Z(any(Z<0,2),:) = [];
        [~,index]       = unique(roundn(Z,-4),'rows','stable');
        Z               = Z(index,:);
        W=Z.*repmat(Zmax-Zmin,size(Z,1),1);
        [~,Region] = max(1-pdist2(PopObj,W,'cosine'),[],2);
        %[~,Region] = max(1-pdist2(PopObj,W,'cosine'),[],2);
        Crowd     = hist(Region,1:size(Z,1));
    end
    Z=Z.*repmat(Zmax-Zmin,size(Z,1),1);
%     Z=max(Z,1e-6);
    %% Deletion of reference points
    Z(intersect(K+1:size(Z,1),find(~Crowd)),:) = [];
    if size(Z,1) > N
        idx = K + randperm(size(Z,1)-K,size(Z,1)-N);
        Z(idx,:) = [];
    end
    %% if size(Z,1)<N,keep adding new weight vectors by combining existing (old)w_vs and popobj
%     [cosin_val,Region] = max(1-pdist2(PopObj,Z,'cosine'),[],2);
%     %����ֵԽС��˵���н�Խ��
%     [~,idx_pop] = sort(cosin_val);
    %�н����ĸ��壬����ֻ�������Ȩ�����������µ�Ȩ������
    %�������ʹ��һ��
    while(size(Z,1)~=N)
        [cosin_val,Region] = max(1-pdist2(PopObj,Z,'cosine'),[],2);
        Crowd      = hist(Region,1:size(Z,1));
        index_maxCrowd= find(Crowd==max(Crowd)); %the most crowded subregion(s)' index
        index_pop  = find(ismember(Region,index_maxCrowd)); %the corresponding individual(s)' index
%         [cosin_val,Region] = max(1-pdist2(PopObj,Z,'cosine'),[],2);
        %����ֵԽС��˵���н�Խ��
        subcosin_val=cosin_val(index_pop);
        [~,idx_indi] = min(subcosin_val);
        idx_indi=index_pop(idx_indi); %��ԭ�������index
        %combine the solution and the nearest z
        %norm
        a1=PopObj(idx_indi,:)./norm(PopObj(idx_indi,:));
        a2=Z(Region(idx_indi),:)./norm(Z(Region(idx_indi),:));
        new_z=(PopObj(idx_indi,:).*(M-1)+Z(Region(idx_indi),:))./M;
%         new_z=(PopObj(idx_indi,:).*(M-1)+Z(Region(idx_indi),:))./M;
        Z=[Z;new_z];   
    end
end